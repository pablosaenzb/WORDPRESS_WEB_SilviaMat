//Use Strict Mode
(function ($) {
    "use strict";

    //Begin - Window Load
    jQuery(document).ready(function($){
     $('.color-picker').wpColorPicker();
    });

    //End - Use Strict mode
})(jQuery);